# Solution: Beam Deflection - Functions Module

import numpy as np


def beam_reactions(P, a, L):
    """Compute support reactions for a simply supported beam.

    Args:
        P: Point load magnitude (N)
        a: Distance from left support to load (m)
        L: Beam length (m)

    Returns:
        Tuple of (RA, RB) reaction forces (N)
    """
    RA = P * (L - a) / L
    RB = P * a / L
    return (RA, RB)


def beam_deflection(x, P, a, L, E, I):
    """Compute deflection at position x using Euler-Bernoulli beam theory.

    Args:
        x: Position along beam (m), scalar or array
        P: Point load magnitude (N)
        a: Distance from left support to load (m)
        L: Beam length (m)
        E: Young's modulus (Pa)
        I: Second moment of area (m^4)

    Returns:
        Deflection at position x (m), positive downward
    """
    b = L - a
    x = np.asarray(x, dtype=float)
    v = np.zeros_like(x)

    # Region 1: 0 <= x <= a
    mask1 = (x >= 0) & (x <= a)
    x1 = x[mask1]
    v[mask1] = (P * b * x1 / (6 * L * E * I)) * (L**2 - b**2 - x1**2)

    # Region 2: a < x <= L
    mask2 = (x > a) & (x <= L)
    x2 = x[mask2]
    v[mask2] = (P * b * x2 / (6 * L * E * I)) * (
        L**2 - b**2 - x2**2
    ) + P * (x2 - a)**3 / (6 * E * I)

    return v


def max_deflection(P, a, L, E, I):
    """Compute the maximum deflection magnitude of the beam.

    Args:
        P: Point load magnitude (N)
        a: Distance from left support to load (m)
        L: Beam length (m)
        E: Young's modulus (Pa)
        I: Second moment of area (m^4)

    Returns:
        Maximum deflection magnitude (m), always positive
    """
    x_positions = np.linspace(0, L, 1000)
    deflections = beam_deflection(x_positions, P, a, L, E, I)
    return float(np.max(np.abs(deflections)))
