import numpy as np


def beam_reactions(P, a, L):
    RA = P * (L - a) / L
    RB = P * a / L
    return (RA, RB)


def beam_deflection(x, P, a, L, E, I):
    b = L - a
    x = np.asarray(x, dtype=float)
    v = np.zeros_like(x)

    mask1 = (x >= 0) & (x <= a)
    x1 = x[mask1]
    v[mask1] = (P * b * x1 / (6 * L * E * I)) * (L**2 - b**2 - x1**2)

    mask2 = (x > a) & (x <= L)
    x2 = x[mask2]
    v[mask2] = (P * b * x2 / (6 * L * E * I)) * (
        L**2 - b**2 - x2**2
    ) + P * (x2 - a)**3 / (6 * E * I)

    return v
