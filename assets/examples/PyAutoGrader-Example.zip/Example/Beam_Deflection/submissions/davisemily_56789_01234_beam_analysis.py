import numpy as np
import matplotlib.pyplot as plt
from myfunctions import beam_reactions, beam_deflection

L = 10
E = 200e9
I = 8.33e-6
P = 5000
a = 4

RA, RB = beam_reactions(P, a, L)
print(f"Reaction at A: {RA:.1f} N")
print(f"Reaction at B: {RB:.1f} N")

x = np.linspace(0, L, 100)
deflection = beam_deflection(x, P, a, L, E, I)

plt.figure(figsize=(10, 6))
plt.plot(x, deflection)
plt.xlabel("Position (m)")
plt.ylabel("Deflection (m)")
plt.title("Beam Deflection")
plt.grid(True)
plt.show()
