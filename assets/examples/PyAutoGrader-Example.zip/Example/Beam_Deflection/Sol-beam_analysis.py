# Solution: Beam Deflection - Main Analysis Script

import numpy as np
import matplotlib.pyplot as plt
from myfunctions import beam_reactions, beam_deflection, max_deflection

# Beam parameters
L = 10          # Beam length (m)
E = 200e9       # Young's modulus (Pa) - steel
I = 8.33e-6     # Second moment of area (m^4)
P = 5000        # Point load (N)
a = 4           # Load position from left support (m)

# Compute reactions
RA, RB = beam_reactions(P, a, L)
print(f"Reaction at A: {RA:.1f} N")
print(f"Reaction at B: {RB:.1f} N")

# Compute deflection curve
x = np.linspace(0, L, 100)
deflection = beam_deflection(x, P, a, L, E, I)

# Find maximum deflection
max_def = max_deflection(P, a, L, E, I)
print(f"Maximum deflection: {max_def:.6f} m")

# Plot
plt.figure(figsize=(10, 6))
plt.plot(x, deflection)
plt.xlabel("Position (m)")
plt.ylabel("Deflection (m)")
plt.title("Beam Deflection")
plt.grid(True)
plt.show()
