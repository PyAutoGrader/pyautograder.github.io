# Name: Sarah Williams
# Weather Data Analysis

import numpy as np

data = np.genfromtxt("weather_data.csv", delimiter=",", skip_header=1, usecols=(1, 2))

h = 0
l = 0
max_temp = float("-inf")
min_temp = float("inf")
hot_days = 0
n = 0

for row in data:
    t = row[0]
    w = row[1]

    h += t
    l += w
    n += 1

    if t > max_temp:
        max_temp = t
    if w < min_temp:
        min_temp = w
    if t > 85:
        hot_days += 1

avg_high = h / n
avg_low = l / n

print("Weather Data Analysis Results")
print(f"Average High Temperature: {avg_high:.1f} F | Average Low Temperature: {avg_low:.1f} F | Max: {max_temp} F | Min: {min_temp} F | Hot Days: {hot_days}")
