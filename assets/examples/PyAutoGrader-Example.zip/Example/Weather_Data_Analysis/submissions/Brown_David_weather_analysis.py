# Name: David Brown
# Weather Data Analysis

import numpy as np

data = np.genfromtxt("weather_data.csv", delimiter=",", skip_header=1, usecols=(1, 2))

total_high = 0
total_low = 0
max_temp = float("-inf")
min_temp = float("inf")
hot_days = 0
count = 0

for row in data:
    high = int(row[0])
    low = int(row[1])

    total_high += high
    total_low += low
    count += 1

    if high > max_temp:
        max_temp = high
    if low < min_temp:
        min_temp = low
    if high >= 85:
        hot_days += 1

avg_high = total_high / count + 5
avg_low = total_low / count

print(f"Max temp was {max_temp}, min temp was {min_temp}")
print(f"There were {hot_days} hot days")
print(f"Avg high was {avg_high:.1f}, avg low was {avg_low:.1f}")
