# Name: Emily Davis
# Assignment: Weather Data Analysis
# Course: ENGR 101

import numpy as np

data = np.genfromtxt("weather_data.csv", delimiter=",", skip_header=1, usecols=(1, 2))

total_high = 0
total_low = 0
max_temp = float("-inf")
min_temp = float("inf")
hot_days = 0
count = 0

for row in data:
    high = row[0]
    low = row[1]

    total_high += high
    total_low += low
    count += 1

    if high > max_temp:
        max_temp = high
    if low < min_temp:
        min_temp = low
    if high > 85:
        hot_days += 1

avg_high = total_high / count
avg_low = total_low / count

if __name__ == "__main__":
    print("Weather Data Analysis Results")
    print(f"Average High Temperature: {avg_high:.1f} F")
    print(f"Average Low Temperature: {avg_low:.1f} F")
    print(f"Maximum Temperature: {max_temp} F")
    print(f"Minimum Temperature: {min_temp} F")
    print(f"Number of Hot Days (>85 F): {hot_days}")
