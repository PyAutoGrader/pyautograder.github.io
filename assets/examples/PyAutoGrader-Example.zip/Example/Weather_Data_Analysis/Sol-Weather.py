# Solution: Weather Data Analysis
# This file is used by PyAutoGrader for compare_solution tests.

import numpy as np

# Read the CSV file - skip header, load only numeric columns (high and low temps)
data = np.genfromtxt("weather_data.csv", delimiter=",", skip_header=1, usecols=(1, 2))

# Initialize variables
total_high = 0
total_low = 0
max_temp = float("-inf")
min_temp = float("inf")
hot_days = 0
count = 0

# Process each row - high temp is column 0, low temp is column 1
for row in data:
    high = row[0]
    low = row[1]

    total_high += high
    total_low += low
    count += 1

    if high > max_temp:
        max_temp = high
    if low < min_temp:
        min_temp = low
    if high > 85:
        hot_days += 1

# Compute averages
avg_high = total_high / count
avg_low = total_low / count

# Print summary
print("Weather Data Analysis Results")
print(f"Average High Temperature: {avg_high:.1f} F")
print(f"Average Low Temperature: {avg_low:.1f} F")
print(f"Maximum Temperature: {max_temp} F")
print(f"Minimum Temperature: {min_temp} F")
print(f"Number of Hot Days (>85 F): {hot_days}")
